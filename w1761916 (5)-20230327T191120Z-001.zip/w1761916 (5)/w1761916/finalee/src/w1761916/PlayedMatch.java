package w1761916;

import java.io.Serializable;
import java.util.Objects;

public class PlayedMatch implements Serializable {
    private String date;
    private String club1Name;
    private int club1GoalsScored;
    private int club1GoalsReceived;
    private String club1WinState;
    private int club1Points;
    private String club2Name;
    private int club2GoalsScored;
    private int club2GoalsReceived;
    private String club2WinState;
    private int club2Points;

    public PlayedMatch(String date, String club1Name, int club1GoalsScored, int club1GoalsReceived, String club1WinState, int club1Points, String club2Name, int club2GoalsScored, int club2GoalsReceived, String club2WinState, int club2Points) {
        this.date = date;
        this.club1Name = club1Name;
        this.club1GoalsScored = club1GoalsScored;
        this.club1GoalsReceived = club1GoalsReceived;
        this.club1WinState = club1WinState;
        this.club1Points = club1Points;
        this.club2Name = club2Name;
        this.club2GoalsScored = club2GoalsScored;
        this.club2GoalsReceived = club2GoalsReceived;
        this.club2WinState = club2WinState;
        this.club2Points = club2Points;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getClub1Name() {
        return club1Name;
    }

    public void setClub1Name(String club1Name) {
        this.club1Name = club1Name;
    }

    public int getClub1GoalsScored() {
        return club1GoalsScored;
    }

    public void setClub1GoalsScored(int club1GoalsScored) {
        this.club1GoalsScored = club1GoalsScored;
    }

    public int getClub1GoalsReceived() {
        return club1GoalsReceived;
    }

    public void setClub1GoalsReceived(int club1GoalsReceived) {
        this.club1GoalsReceived = club1GoalsReceived;
    }

    public String getClub1WinState() {
        return club1WinState;
    }

    public void setClub1WinState(String club1WinState) {
        this.club1WinState = club1WinState;
    }

    public int getClub1Points() {
        return club1Points;
    }

    public void setClub1Points(int club1Points) {
        this.club1Points = club1Points;
    }

    public String getClub2Name() {
        return club2Name;
    }

    public void setClub2Name(String club2Name) {
        this.club2Name = club2Name;
    }

    public int getClub2GoalsScored() {
        return club2GoalsScored;
    }

    public void setClub2GoalsScored(int club2GoalsScored) {
        this.club2GoalsScored = club2GoalsScored;
    }

    public int getClub2GoalsReceived() {
        return club2GoalsReceived;
    }

    public void setClub2GoalsReceived(int club2GoalsReceived) {
        this.club2GoalsReceived = club2GoalsReceived;
    }

    public String getClub2WinState() {
        return club2WinState;
    }

    public void setClub2WinState(String club2WinState) {
        this.club2WinState = club2WinState;
    }

    public int getClub2Points() {
        return club2Points;
    }

    public void setClub2Points(int club2Points) {
        this.club2Points = club2Points;
    }
}
