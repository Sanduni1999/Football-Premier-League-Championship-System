package w1761916;

import java.util.Objects;

public abstract class FootballClub extends SportsClub implements Comparable<FootballClub> {

    private String clubType;
    private int noOfWins;
    private int noOfDraws;
    private int defeats;
    private int goalsReceived;
    private int goalsScored;
    private int points;
    private int noOfMatchesPlayed;

    public FootballClub(int clubCategory, String clubName, String clubLocation, String clubType) {
        super(clubCategory, clubName, clubLocation);
        this.clubType = clubType;
        this.noOfWins = 0;
        this.noOfDraws = 0;
        this.defeats = 0;
        this.goalsReceived = 0;
        this.goalsScored = 0;
        this.points = 0;
        this.noOfMatchesPlayed = 0;
    }

    public String getClubType() {
        return clubType;
    }

    public void setClubType(String clubType) {
        this.clubType = clubType;
    }

    public int getNoOfWins() {
        return noOfWins;
    }

    public void setNoOfWins(int noOfWins) {
        this.noOfWins = noOfWins;
    }

    public int getNoOfDraws() {
        return noOfDraws;
    }

    public void setNoOfDraws(int noOfDraws) {
        this.noOfDraws = noOfDraws;
    }

    public int getDefeats() {
        return defeats;
    }

    public void setDefeats(int defeats) {
        this.defeats = defeats;
    }

    public int getGoalsReceived() {
        return goalsReceived;
    }

    public void setGoalsReceived(int goalsReceived) {
        this.goalsReceived = goalsReceived;
    }

    public int getGoalsScored() {
        return goalsScored;
    }

    public void setGoalsScored(int goalsScored) {
        this.goalsScored = goalsScored;
    }

    public int getPoints() {
        return points;
    }

    public void setPoints(int points) {
        this.points = points;
    }

    public int getNoOfMatchesPlayed() {
        return noOfMatchesPlayed;
    }

    public void setNoOfMatchesPlayed(int noOfMatchesPlayed) {
        this.noOfMatchesPlayed = noOfMatchesPlayed;
    }

    @Override
    public String toString() {
        return "FootballClub{" +
                super.toString() +
                "clubType='" + clubType + '\'' +
                //", clubID='" + clubID + '\'' +
                ", noOfWins=" + noOfWins +
                ", noOfDraws=" + noOfDraws +
                ", defeats=" + defeats +
                ", GoalsReceived=" + goalsReceived +
                ", GoalsScored=" + goalsScored +
                ", points=" + points +
                ", noOfMatchesPlayed=" + noOfMatchesPlayed +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        FootballClub club = (FootballClub) o;
        return noOfWins == club.noOfWins &&
                noOfDraws == club.noOfDraws &&
                defeats == club.defeats &&
                goalsReceived == club.goalsReceived &&
                goalsScored == club.goalsScored &&
                Double.compare(club.points, points) == 0 &&
                noOfMatchesPlayed == club.noOfMatchesPlayed &&
                Objects.equals(clubType, club.clubType);

    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), clubType, noOfWins, noOfDraws, defeats, goalsReceived, goalsScored, points, noOfMatchesPlayed);
    }

    @Override
    public int compareTo(FootballClub o) {

        if (o.getPoints() != (this.getPoints())) {
            int comparePoints = ((FootballClub) o).getPoints();
            return (int) (comparePoints - this.points);
        } else {
            int goalDifference1 = o.getGoalsScored() - o.getGoalsReceived();
            int goalDifference2 = this.getGoalsScored() - this.getGoalsReceived();
            return (int) (goalDifference1 - goalDifference2);
        }
    }

}