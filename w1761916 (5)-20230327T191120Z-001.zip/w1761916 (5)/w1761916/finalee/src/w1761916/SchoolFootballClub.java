package w1761916;

import java.util.Objects;

public class SchoolFootballClub extends FootballClub {

    public SchoolFootballClub(int clubCategory, String clubName, String clubLocation, String clubType) {
        super(clubCategory, clubName, clubLocation, clubType);
    }

    @Override
    public String toString() {
        return "SchoolFootballClub{" +
                super.toString()+
                '}';
    }
}