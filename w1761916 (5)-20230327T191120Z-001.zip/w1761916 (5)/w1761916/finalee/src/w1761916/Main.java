package w1761916;

import javafx.application.Application;
import javafx.stage.Stage;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Main extends Application {
    static LeagueManager manager = new PremierLeagueManager();
    final static Scanner userInput = new Scanner(System.in);


    public static void main(String[] args) throws IOException, ClassNotFoundException {

        launch();
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        while (true) {
            System.out.println("Welcome to the Premier League system! Please select your preferred option. ");
            System.out.println("1 = Add a football club");
            System.out.println("2 = Delete a football club");
            System.out.println("3 = Show statistics");
            System.out.println("4 = Show Premier League Table");
            System.out.println("5 = Add a Played Match");
            System.out.println("6 = Display League Table in GUI");
            System.out.println("7 = Generate Random Match");
            System.out.println("8 = Display Matches Sorted By Date");
            System.out.println("9 = Search Matches By Date");
            System.out.println("10 = Save data to the text file");
            System.out.println("11 = Load data from the file");
            System.out.println("12 = Quit");

            String choice = userInput.next();
            switch (choice) {
                case "1":
                    addClub();
                    break;

                case "2":
                    deleteClub();
                    break;

                case "3":
                    statistics();
                    break;

                case "4":
                    manager.premierLeagueTable();
                    break;

                case "5":
                    addPlayedMatch();
                    break;

                case "6":
                    manager.displayLeagueTableInGUI();
                    break;

                case "7":
                    manager.generateRandomMatch();
                    break;

                case "8":
                    manager.displayMatchesSortedByDate();
                    break;

                case "9":
                    manager.searchMatchesByDate();
                    break;

                case "10":
                    manager.saveInFile("text.txt");
                    break;
                case "11":
                    manager.loadFile("text.txt");
                    break;

                case "12":
                    System.out.println("Thank you for using the application!");
                    System.exit(1);


                default:
                    System.out.println("Invalid option. Please try again");
            }
        }
    }


    private static void addClub() {

        FootballClub footballClub = null; //to be changed

        int clubCategory;
        while (true) {
            try {
                //clubCategory validation
                System.out.println("Please enter the club Category. 1. Football Club/ 2. Other");
                System.out.println("Please enter the relevant number only. ");

                Scanner userInput = new Scanner(System.in);
                clubCategory = userInput.nextInt();

                if (clubCategory == 1 || clubCategory == 2) {
//                        System.out.println("call");
                    break;
                } else {
                    System.out.println("Wrong club category. Please try again!");
                }
            } catch (InputMismatchException exception) {
                System.out.println("Invalid input type. Please try again.");
            }

        }

        if (clubCategory == 1) {

            System.out.println("Please enter the club name:");
            String clubName = userInput.next();
            System.out.println("Please enter the club location:");
            String clubLocation = userInput.next();

            while (true) {
                System.out.println("Please enter the club type. 1. University Football Club/ 2. School Football Club ");
                System.out.println("Please enter the relevant number only. ");
                String clubType = userInput.next();

                if (clubType.equals("1") || clubType.equals("2")) {

                    if (clubType.equals("1")) {

                        footballClub = new UniversityFootballClub(clubCategory, clubName, clubLocation, clubType);
                        break;
                    } else {

                        footballClub = new SchoolFootballClub(clubCategory, clubName, clubLocation, clubType);
                        break;

                    }

                } else {
                    System.out.println("Wrong club type. Please try again!");
                }

            }
            manager.addClub(footballClub);
            System.out.println("Club has been successfully added to the system.");
            System.out.println();


        } else {
            System.out.println("Contact manager office.");

        }

    }

    private static void deleteClub() {
        System.out.println("Please enter the club name:");
        String clubName = userInput.next();

        manager.deleteClub(clubName);

    }

    private static void statistics() {
        System.out.println("Please enter the club name:");
        String clubName = userInput.next();

        manager.statistics(clubName);


    }

    private static void addPlayedMatch() {

        PlayedMatch playedMatch = null;
        String date;
        int club1Result;
        int club1GoalsScored;
        int club2GoalsScored;

        while (true) {
            System.out.println("Please Enter the Date of the match in YYYY-MM-DD format : ");

            Scanner userInput=new Scanner(System.in);
            date = userInput.nextLine();

            //checking whether the format of the user given date is correct
            //reference: https://stackoverflow.com/questions/2149680/regex-date-format-validation-on-java
            if (date.matches("\\d{4}-\\d{2}-\\d{2}")) {
                break;
            } else {
                System.out.println("Wrong date format. Please try again!");
            }
        }

        System.out.println("Please enter the 1st club name:");
        Scanner input=new Scanner(System.in);
        String club1Name = input.nextLine();


        while (true) {
            //validation of the user given result(won or defeated or draw)
            try {
                System.out.println("1.Won 2.Defeated 3.Draw");
                System.out.println("Enter the relevant number only.");
                Scanner userInput=new Scanner(System.in);
                club1Result = userInput.nextInt();
                if (club1Result == 1 || club1Result == 2 || club1Result == 3) {
                    break;
                }
            } catch (InputMismatchException exception) {
                System.out.println("Wrong input type. Please try again!");
            }
        }

        while (true) {
            try {
                System.out.println("Please enter the goals scored");
                Scanner userInput=new Scanner(System.in);
                club1GoalsScored = userInput.nextInt();
                break;
            } catch (InputMismatchException exception) {
                System.out.println("Wrong input type. Please try again!");
            }
        }

        System.out.println("Please enter the 2nd club name:");
        Scanner input2=new Scanner(System.in);
        String club2Name = input2.next();

        while (true) {
            try {
                System.out.println("Please enter the goals scored");
                Scanner userInput=new Scanner(System.in);
                club2GoalsScored = userInput.nextInt();
                break;
            } catch (InputMismatchException exception) {
                System.out.println("Wrong input type. Please try again!");
            }
        }

        int club1GoalsReceived;
        int club1Points = 0;
        int club2GoalsReceived;
        int club2Points = 0;
        String club1WinState;
        String club2WinState;

        club1GoalsReceived = club2GoalsScored;
        club2GoalsReceived = club1GoalsScored;

        //In the premier league, if a club has won 3 points will be added and if both clubs have been draw 1 point will be added to each club
        //reference: https://www.clubworldranking.com/how-are-the-football-world-rankings-calculated
        if(club1Result == 1) {
            club1Points =+ 3;
            club1WinState = "Won";
            club2WinState = "Defeated";
        } else if(club1Result == 2) {
            club2Points =+ 3;
            club1WinState = "Defeated";
            club2WinState = "Won";
        } else {
            club1Points += 1;
            club2Points += 1;
            club1WinState = "Draw";
            club2WinState = "Draw";
        }

        playedMatch = new PlayedMatch(date, club1Name, club1GoalsScored, club1GoalsReceived, club1WinState, club1Points, club2Name, club2GoalsScored, club2GoalsReceived, club2WinState, club2Points);

        manager.addPlayedMatch(playedMatch);
        System.out.println();
    }

}
