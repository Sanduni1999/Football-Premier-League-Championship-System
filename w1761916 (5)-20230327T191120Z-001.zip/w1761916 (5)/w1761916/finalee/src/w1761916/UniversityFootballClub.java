package w1761916;


import java.util.Objects;

public class UniversityFootballClub extends FootballClub {

    public UniversityFootballClub(int clubCategory, String clubName, String clubLocation, String clubType) {
        super(clubCategory, clubName, clubLocation, clubType);
    }

    @Override
    public String toString() {
        return "UniversityFootballClub{" +
                super.toString()+
                '}';
    }

}


