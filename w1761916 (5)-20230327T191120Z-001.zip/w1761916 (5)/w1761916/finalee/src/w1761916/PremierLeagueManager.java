package w1761916;

import javafx.beans.binding.Bindings;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.text.Text;
import javafx.scene.text.TextBoundsType;
import javafx.stage.Stage;
import org.controlsfx.control.textfield.TextFields;

import java.io.*;
import java.time.Month;
import java.time.Year;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

public class PremierLeagueManager implements LeagueManager,Serializable {

    private List <FootballClub> footballClubList=new ArrayList<>();
    private List <PlayedMatch> playedMatchList=new ArrayList<>();
    ArrayList<FootballClub> pointsSortedClubs = new ArrayList<>();
    ArrayList<FootballClub> goalScoredSortedClubs = new ArrayList<>();
    ArrayList<FootballClub> noOfWinsSortedClubs=new ArrayList<>();

    @Override
    public void addClub(FootballClub footballClub) {
        if(footballClubList.contains(footballClub)){
            System.out.println("Already registered.");
            System.out.println();
        }else {
            footballClubList.add(footballClub);
        }
//        System.out.println(footballClubList);
        System.out.println();

    }

    @Override
    public void deleteClub(String clubName) {

        for(FootballClub footballClub:footballClubList ){
            if(footballClub.getClubName().equals(clubName)){
                footballClubList.remove(footballClub);
                System.out.printf("%s has been removed from the system.",footballClub instanceof UniversityFootballClub? "University Football Club":"School Football Club");
                System.out.println();
                break;
            }else{
                System.out.println("Invalid club name!");
                System.out.println();
            }
        }

        System.out.println();

    }

    @Override
    public void statistics(String clubName) {

        List <FootballClub> exactFootballClubList=new ArrayList<>();

        for(FootballClub footballClub:footballClubList ){
            if(footballClub.getClubName().equals(clubName)){
                exactFootballClubList.add(footballClub);
                System.out.println("Club Category = Football Club");
                System.out.println("Club Name = "+exactFootballClubList.get(0).getClubName());
                System.out.println("Club Location = "+exactFootballClubList.get(0).getClubLocation());
                System.out.println("Club Type = "+(exactFootballClubList.get(0).getClubType().equals("1") ? "University Football Club" : "School Football Club"));
                System.out.println("No. of Wins = "+exactFootballClubList.get(0).getNoOfWins());
                System.out.println("No. of Draws = "+exactFootballClubList.get(0).getNoOfDraws());
                System.out.println("Defeats = "+exactFootballClubList.get(0).getDefeats());
                System.out.println("Goals Received = "+exactFootballClubList.get(0).getGoalsScored());
                System.out.println("Goals Scored = "+exactFootballClubList.get(0).getGoalsReceived());
                System.out.println("Points = "+exactFootballClubList.get(0).getPoints());
                System.out.println("No. of Matches Played = "+exactFootballClubList.get(0).getNoOfMatchesPlayed());


                System.out.println();
                //System.out.println(exactFootballClubList.size());

                break;
            }else{
                System.out.println("Invalid club name.");
                System.out.println();
            }
        }
        //SchoolFootballClub{FootballClub{clubCategory='1', clubName='anula', clubLocation='nugegoda'}clubType='2', noOfWins=0, noOfDraws=0, defeats=0, GoalsReceived=0, GoalsScored=0, points=0.0, noOfMatchesPlayed=0}}

    }

    @Override
    public void premierLeagueTable() {

        Collections.sort(footballClubList);

        System.out.printf("%n%-20s%-20s%-10s%-10s%-10s%-15s%-15s%-10s%-10s",
                "Club Name", "Club Location", "noOfWins", "noOfDraws", "defeats", "GoalsReceived", "GoalsScored", "points", "noOfMatchesPlayed");
        for (FootballClub footballClub : footballClubList) {

                System.out.printf("%n%-20s%-20s%-10d%-10d%-10d%-15d%-15d%-10d%-10d", footballClub.getClubName(),
                                footballClub.getClubLocation(), footballClub.getNoOfWins(), footballClub.getNoOfDraws(),
                        footballClub.getDefeats(), footballClub.getGoalsReceived(), footballClub.getGoalsScored(), footballClub.getPoints(),
                        footballClub.getNoOfMatchesPlayed());


        }
        System.out.println("\n");
    }

    @Override
    public void addPlayedMatch(PlayedMatch playedMatch) {
        playedMatchList.add(playedMatch);
        System.out.println();

        // Update data of the two football clubs with the details related to the added football match
        // Checking whether user given club names are in the foodballclub list and updating the records
        for(FootballClub club: footballClubList) {
            if(club.getClubName().equals(playedMatch.getClub1Name())) {
                club.setGoalsScored(club.getGoalsScored() + playedMatch.getClub1GoalsScored());
                club.setGoalsReceived(club.getGoalsReceived() + playedMatch.getClub1GoalsReceived());
                if(playedMatch.getClub1WinState().equals("Won")) {
                    club.setNoOfWins(club.getNoOfWins() + 1);
                } else if(playedMatch.getClub1WinState().equals("Defeated")) {
                    club.setDefeats(club.getDefeats() + 1);
                } else {
                    club.setNoOfDraws(club.getNoOfDraws() + 1);
                }
                club.setPoints(club.getPoints() + playedMatch.getClub1Points());
            } else if (club.getClubName().equals(playedMatch.getClub2Name())) {
                club.setGoalsScored(club.getGoalsScored() + playedMatch.getClub2GoalsScored());
                club.setGoalsReceived(club.getGoalsReceived() + playedMatch.getClub2GoalsReceived());
                if(playedMatch.getClub2WinState().equals("Won")) {
                    club.setNoOfWins(club.getNoOfWins() + 1);
                } else if(playedMatch.getClub2WinState().equals("Defeated")) {
                    club.setDefeats(club.getDefeats() + 1);
                } else {
                    club.setNoOfDraws(club.getNoOfDraws() + 1);
                }
                club.setPoints(club.getPoints() + playedMatch.getClub2Points());
            }
        }

    }


    public void saveInFile(String fileName) throws IOException {
        FileOutputStream fileOutputStream=new FileOutputStream(fileName);
        ObjectOutputStream objectOutputStream=new ObjectOutputStream(fileOutputStream);

        //saving all the records of the footballClubList & playedMatchList to a text file using objectOutputStream
        objectOutputStream.writeObject(footballClubList);
        objectOutputStream.writeObject(playedMatchList);

        objectOutputStream.flush();
        fileOutputStream.close();
        objectOutputStream.close();

        System.out.println("All the data has been saved in a file.");
        System.out.println();


    }


    public void loadFile(String fileName) throws IOException, ClassNotFoundException {
        FileInputStream fileInputStream=new FileInputStream(fileName);
        ObjectInputStream objectInputStream=new ObjectInputStream(fileInputStream);

        for(;;){
            try{
                //taking all the records of FootballClub
                List<FootballClub> clubs = (ArrayList<FootballClub>) objectInputStream.readObject();
                for (FootballClub club : clubs) {
                    footballClubList.add(club);
                }
                //taking all the records of PlayedMatch
                List<PlayedMatch> matches = (ArrayList<PlayedMatch>) objectInputStream.readObject();
                for (PlayedMatch match : matches) {
                    playedMatchList.add(match);
                }
            }catch (EOFException e){
                break;
            }
        }

        fileInputStream.close();
        objectInputStream.close();

        System.out.println("All the data has been loaded.");
        System.out.println();

    }


    public void displayLeagueTableInGUI() {

            GridPane gridlayout = new GridPane();
            gridlayout.setStyle("-fx-background-color:#C31F6C");
            gridlayout.setPadding(new Insets(20, 20, 20, 20));
            gridlayout.setVgap(15);
            gridlayout.setHgap(15);

            TableView<FootballClub> leagueTable = new TableView<>(); //create the table
            leagueTable.setEditable(false);
            leagueTable.setStyle("-fx-background-color: #FFFFFF; -fx-cell-size: 40; -fx-font-family: PremierSans-Regular,Arial; -fx-font-size: 20");
            Label placeHolder = new Label("There aren't any football clubs in the Premier League at the moment.\n" +
                    "Therefore, there are no statistics to show in the Premier League Table"); //set a message to display if there are no football clubs currently playing in the Premier League
            placeHolder.setStyle("-fx-font-family: PremierSans-Bold,Arial; -fx-font-size: 30; -fx-font-weight: BOLD; -fx-text-fill: #8A1259; -fx-text-alignment: center");
            leagueTable.setPlaceholder(placeHolder);

            // create labels

            Label sortByLabel = new Label("Sort By : ");
            sortByLabel.setStyle("-fx-font-family: PremierSans-Bold,Arial; -fx-font-size: 22; -fx-font-weight: BOLD; -fx-text-fill: #40023F");
            ObservableList<String> sortingOptions = FXCollections.observableArrayList("Points", "Goals Scored", "No of wins"); //create an ObservableList to store sorting options
            ChoiceBox<String> sortOption = new ChoiceBox<>(sortingOptions);
            sortOption.setValue(sortingOptions.get(0));

            TableColumn<FootballClub, String> club = new TableColumn<>("Club"); //create club column
            club.setCellValueFactory(clubData -> Bindings.createStringBinding(() -> clubData.getValue().getClubName() + ", " + clubData.getValue().getClubLocation()));
            club.setSortable(false);
            club.setPrefWidth(400);

            TableColumn<FootballClub, Integer> played = new TableColumn<>("Played"); //create played column
            played.setCellValueFactory(playedData -> new ReadOnlyObjectWrapper<>(playedData.getValue().getNoOfMatchesPlayed()));
            played.setSortable(false);
            played.setPrefWidth(155);

            TableColumn<FootballClub, Integer> won = new TableColumn<>("Won"); //create won column
            won.setCellValueFactory(wonData -> new ReadOnlyObjectWrapper<>(wonData.getValue().getNoOfWins()));
            won.setSortable(false);
            won.setPrefWidth(155);

            TableColumn<FootballClub, Integer> drawn = new TableColumn<>("Drawn"); //create drawn column
            drawn.setCellValueFactory(drawnData -> new ReadOnlyObjectWrapper<>(drawnData.getValue().getNoOfDraws()));
            drawn.setSortable(false);
            drawn.setPrefWidth(155);

            TableColumn<FootballClub, Integer> lost = new TableColumn<>("Lost"); //create lost column
            lost.setCellValueFactory(lostData -> new ReadOnlyObjectWrapper<>(lostData.getValue().getDefeats()));
            lost.setSortable(false);
            lost.setPrefWidth(155);

            TableColumn<FootballClub, Integer> goalsScored = new TableColumn<>("Goals Scored"); //create goalsScored column
            goalsScored.setCellValueFactory(goalsScoredData -> new ReadOnlyObjectWrapper<>(goalsScoredData.getValue().getGoalsScored()));
            goalsScored.setSortable(false);
            goalsScored.setPrefWidth(155);

            TableColumn<FootballClub, Integer> goalsReceived = new TableColumn<>("Goals Received"); //create goalsReceived column
            goalsReceived.setCellValueFactory(goalsReceivedData -> new ReadOnlyObjectWrapper<>(goalsReceivedData.getValue().getGoalsReceived()));
            goalsReceived.setSortable(false);
            goalsReceived.setPrefWidth(155);


            TableColumn<FootballClub, Integer> points = new TableColumn<>("Points"); //create points column
            points.setCellValueFactory(pointsData -> new ReadOnlyObjectWrapper<>(pointsData.getValue().getPoints()));
            points.setSortable(false);
            points.setPrefWidth(155);

            ObservableList<FootballClub> tableData = FXCollections.observableArrayList(footballClubList); //create an ObservableList to store footballClub details
            leagueTable.getColumns().addAll(club, played, won, drawn, lost, goalsScored, goalsReceived, points);
            leagueTable.setItems(tableData);
            leagueTable.setPrefSize(1800, 775);

            // add elements to the GridPane

            gridlayout.add(sortByLabel, 2, 3);
            gridlayout.add(sortOption, 4, 3);
            gridlayout.add(leagueTable, 1, 5, 5, 25);

            sortOption.setOnAction(event -> {
                String selectedSortOption = sortOption.getValue();
                tableData.setAll(updateClubPositionInGUI(selectedSortOption));
            });

            Scene scene = new Scene(gridlayout, 1900, 975);
            scene.setFill(Paint.valueOf("#C31F6C"));
            Stage stage = new Stage();
            stage.setTitle("Premier League Table");
            stage.sizeToScene();
            stage.setScene(scene);
            stage.showAndWait();

        }


    public void generateRandomMatch() { //generate a random footballMatch
        if (footballClubList.size() >= 2) { //check whether there are at least two football clubs currently playing in the Premier League
            GridPane gridlayout = new GridPane();
            gridlayout.setStyle("-fx-background-color:#E0DADA");
            gridlayout.setPadding(new Insets(20, 20, 20, 20));
            gridlayout.setVgap(15);

            // create labels,buttons and shapes
            Label title = new Label("Premier League ");
            title.setStyle("-fx-font-family: PremierSans-Bold,Arial; -fx-font-size: 35; -fx-font-weight: BOLD; -fx-text-fill: #FE0002");
            GridPane.setHalignment(title, HPos.CENTER);

            Button generateMatch = new Button("Generate a random match");
            generateMatch.setPrefSize(400, 100);
            generateMatch.setStyle("-fx-font-family: PremierSans-Bold,Arial; -fx-font-size: 25; -fx-font-weight: BOLD; -fx-background-color: #45004B; -fx-text-fill: #FFFFFF");

            Circle homeTeamCircle = new Circle(150);
            homeTeamCircle.setStyle("-fx-fill: #FFFFFF; -fx-stroke: #E00909; -fx-stroke-width: 4");
            Text homeTeamText = new Text("HOME TEAM");
            homeTeamText.setStyle("-fx-font-family: PremierSans-Bold,Arial; -fx-font-size: 23; -fx-font-weight: BOLD; -fx-text-alignment: center");
            GridPane.setHalignment(homeTeamText, HPos.CENTER);
            homeTeamText.setBoundsType(TextBoundsType.VISUAL);

            Circle awayTeamCircle = new Circle(150);
            awayTeamCircle.setStyle("-fx-fill: #FFFFFF; -fx-stroke: #E00909; -fx-stroke-width: 4");
            Text awayTeamText = new Text("AWAY TEAM");
            awayTeamText.setStyle("-fx-font-family: PremierSans-Bold,Arial; -fx-font-size: 23; -fx-font-weight: BOLD; -fx-text-alignment: center");
            GridPane.setHalignment(awayTeamText, HPos.CENTER);
            awayTeamText.setBoundsType(TextBoundsType.VISUAL);

            Line connectingLine = new Line(4,4,300,4);
            connectingLine.setStyle("-fx-stroke: #E00909; -fx-stroke-width: 5");
            Label versusLabel = new Label("VS");
            versusLabel.setStyle("-fx-font-family: PremierSans-Bold,Arial; -fx-font-size: 27; -fx-font-weight: BOLD; -fx-text-fill: #875587; -fx-label-padding: 0 130 100 130");

            Label homeTeamLabel = new Label();
            homeTeamLabel.setStyle("-fx-font-family: PremierSans-Bold,Arial; -fx-font-size: 28; -fx-font-weight: BOLD; -fx-text-alignment: center");
            GridPane.setHalignment(homeTeamLabel, HPos.CENTER);

            Label awayTeamLabel = new Label();
            awayTeamLabel.setStyle("-fx-font-family: PremierSans-Bold,Arial; -fx-font-size: 28; -fx-font-weight: BOLD; -fx-text-alignment: center");
            GridPane.setHalignment(awayTeamLabel, HPos.CENTER);

            Label matchDateLabel = new Label();
            matchDateLabel.setStyle("-fx-font-family: PremierSans-Bold,Arial; -fx-font-size: 28; -fx-font-weight: BOLD; -fx-text-alignment: center; -fx-text-fill: BLUE");
            GridPane.setHalignment(matchDateLabel, HPos.CENTER);

            Label goalsScoredLabel = new Label();
            goalsScoredLabel.setStyle("-fx-font-family: PremierSans-Bold,Arial; -fx-font-size: 30; -fx-font-weight: BOLD; -fx-text-alignment: center; -fx-text-fill: RED;" +
                    " -fx-background-color: #EB8D9C");
            GridPane.setHalignment(goalsScoredLabel,HPos.CENTER);

            Label homeTeamScoreLabel = new Label();
            homeTeamScoreLabel.setStyle("-fx-font-family: PremierSans-Bold,Arial; -fx-font-size: 28; -fx-font-weight: BOLD; -fx-text-alignment: center; -fx-text-fill: BLUE");
            GridPane.setHalignment(homeTeamScoreLabel, HPos.CENTER);

            Label awayTeamScoreLabel = new Label();
            awayTeamScoreLabel.setStyle("-fx-font-family: PremierSans-Bold,Arial; -fx-font-size: 28; -fx-font-weight: BOLD; -fx-text-alignment: center; -fx-text-fill: BLUE");
            GridPane.setHalignment(awayTeamScoreLabel, HPos.CENTER);

            // add elements to the GridPane
            gridlayout.add(title,3,1,3,1);
            gridlayout.add(generateMatch,1,2);
            gridlayout.add(homeTeamCircle,3,4);
            gridlayout.add(homeTeamText,3,4);
            gridlayout.add(awayTeamCircle,5,4);
            gridlayout.add(awayTeamText,5,4);
            gridlayout.add(connectingLine,4,4);
            gridlayout.add(versusLabel,4,4);
            gridlayout.add(homeTeamLabel,3,5);
            gridlayout.add(awayTeamLabel,5,5);
            gridlayout.add(matchDateLabel,4,5);
            gridlayout.add(goalsScoredLabel,4,6);
            gridlayout.add(homeTeamScoreLabel,3,6);
            gridlayout.add(awayTeamScoreLabel,5,6);

            generateMatch.setOnAction(event -> {
                boolean uniqueMatch = false;
                while (!uniqueMatch) {
                    Random randomNumber = new Random();
                    int homeTeamIndex = randomNumber.nextInt(footballClubList.size());
                    FootballClub homeTeam = footballClubList.get(homeTeamIndex); // get a random footballClub for homeTeam
                    int awayTeamIndex = randomNumber.nextInt(footballClubList.size());
                    while (awayTeamIndex == homeTeamIndex) { //check whether the awayTeam is the same as the homeTeam
                        awayTeamIndex = randomNumber.nextInt(footballClubList.size());
                    }
                    FootballClub awayTeam = footballClubList.get(awayTeamIndex);  // get a random footballClub for awayTeam
                    int year = randomNumber.nextInt(22) + 2000; //get a random year from valid years
                    int month = randomNumber.nextInt(12) + 1; //generate a random number from 1 to 12 for month
                    int daysInMonth = Month.of(month).length(Year.isLeap(year)); //check number of available dates in the selected month
                    int date = randomNumber.nextInt(daysInMonth) + 1; //generate a random number from 1 to maximum days in the selected month, for date
                    String matchDate = year + "-" + month + "-" + date;
                    int homeTeamScore = randomNumber.nextInt(11); //generate a random number from 0 to 10 for homeTeamScore
                    int awayTeamScore = randomNumber.nextInt(11); //generate a random number from 0 to 10 for awayTeamScore

                    boolean duplicateMatch = false;
                    for (PlayedMatch footballMatch : playedMatchList) { //check whether the same footballMatch details has been added or generated before
                        if (footballMatch.getClub1Name().equals(homeTeam.getClubName()) && footballMatch.getClub2Name().equals(awayTeam.getClubName()) && footballMatch.getDate().equals(matchDate) &&
                                footballMatch.getClub1GoalsScored() == homeTeamScore && footballMatch.getClub2GoalsScored() == awayTeamScore) {
                            duplicateMatch = true;
                            break;
                        }
                    }
                    if (!duplicateMatch) {
                        uniqueMatch = true;

                        String club1WinState;
                        String club2WinState;
                        int club1Points;
                        int club2Points;

                        if(homeTeamScore > awayTeamScore) {
                            club1WinState = "Won";
                            club2WinState = "Defeated";
                            club1Points = 3;
                            club2Points = 0;
                        } else if (homeTeamScore < awayTeamScore) {
                            club1WinState = "Defeated";
                            club2WinState = "Won";
                            club1Points = 0;
                            club2Points = 3;
                        } else {
                            club1WinState = "Draw";
                            club2WinState = "Draw";
                            club1Points = 1;
                            club2Points = 1;
                        }

                        PlayedMatch footballMatch = new PlayedMatch(matchDate,homeTeam.getClubName(),homeTeamScore,awayTeamScore,club1WinState,club1Points,awayTeam.getClubName(),awayTeamScore,homeTeamScore,club2WinState,club2Points); // create footballMatch object
                        playedMatchList.add(footballMatch);
                        homeTeamLabel.setText("HOME TEAM");
                        awayTeamLabel.setText("AWAY TEAM");
                        goalsScoredLabel.setText("GOALS SCORED");
                        homeTeamText.setText(homeTeam.getClubName() + "\n" + homeTeam.getClubLocation());
                        awayTeamText.setText(awayTeam.getClubName() + "\n" + awayTeam.getClubLocation());
                        matchDateLabel.setText(matchDate);
                        homeTeamScoreLabel.setText(String.valueOf(homeTeamScore));
                        awayTeamScoreLabel.setText(String.valueOf(awayTeamScore));

                        for(FootballClub club: footballClubList) {
                            if(club.getClubName().equals(homeTeam.getClubName())) {
                                club.setGoalsScored(club.getGoalsScored() + homeTeam.getGoalsScored());
                                club.setGoalsReceived(club.getGoalsReceived() + homeTeam.getGoalsReceived());
                                if(club1WinState.equals("Won")) {
                                    club.setNoOfWins(club.getNoOfWins() + 1);
                                } else if(club1WinState.equals("Defeated")) {
                                    club.setDefeats(club.getDefeats() + 1);
                                } else {
                                    club.setNoOfDraws(club.getNoOfDraws() + 1);
                                }
                                club.setPoints(club.getPoints() + homeTeam.getPoints());
                            } else if (club.getClubName().equals(awayTeam.getClubName())) {
                                club.setGoalsScored(club.getGoalsScored() + awayTeam.getGoalsScored());
                                club.setGoalsReceived(club.getGoalsReceived() + awayTeam.getGoalsReceived());
                                if(club2WinState.equals("Won")) {
                                    club.setNoOfWins(club.getNoOfWins() + 1);
                                } else if(club2WinState.equals("Defeated")) {
                                    club.setDefeats(club.getDefeats() + 1);
                                } else {
                                    club.setNoOfDraws(club.getNoOfDraws() + 1);
                                }
                                club.setPoints(club.getPoints() + awayTeam.getPoints());
                            }
                        }
                    }
                }
            });

            Scene scene = new Scene(gridlayout,1900,975);
            scene.setFill(Paint.valueOf("#E0DADA"));
            Stage stage = new Stage();
            stage.setTitle("Generate a random football match");
            stage.sizeToScene();
            stage.setScene(scene);
            stage.showAndWait();
        } else {
            System.out.println("To generate a random football match there should be at least two football clubs which are currently playing in the Premier League");
        }
    }

    public void displayMatchesSortedByDate() {
        GridPane gridlayout = new GridPane();
        gridlayout.setStyle("-fx-background-color:#870C21");
        gridlayout.setPadding(new Insets(20, 20, 20, 20));
        gridlayout.setVgap(15);
        gridlayout.setHgap(15);

        TableView<PlayedMatch> matchTable = new TableView<>();  //create the table
        matchTable.setEditable(false);
        matchTable.setStyle("-fx-background-color: #FFFFFF; -fx-cell-size: 40; -fx-font-family: PremierSans-Regular,Arial; -fx-font-size: 20");
        Label placeHolder = new Label("There aren't any football matches played in the Premier League yet.");
        placeHolder.setStyle("-fx-font-family: PremierSans-Bold,Arial; -fx-font-size: 30; -fx-font-weight: BOLD; -fx-text-fill: #EB0725; -fx-text-alignment: center");
        matchTable.setPlaceholder(placeHolder);

        // create labels
        Label title = new Label("Premier League ");
        title.setStyle("-fx-font-family: PremierSans-Bold,Arial; -fx-font-size: 35; -fx-font-weight: BOLD; -fx-text-fill: #BDBD11");
        GridPane.setHalignment(title, HPos.CENTER);

        TableColumn<PlayedMatch, String> homeTeam = new TableColumn<>("Home Team"); //create homeTeam column
        homeTeam.setCellValueFactory(homeTeamData -> Bindings.createStringBinding(() -> homeTeamData.getValue().getClub1Name()));
        homeTeam.setSortable(false);
        homeTeam.setPrefWidth(400);

        TableColumn<PlayedMatch, String> awayTeam = new TableColumn<>("Away Team"); //create awayTeam column
        awayTeam.setCellValueFactory(awayTeamData -> Bindings.createStringBinding(() -> awayTeamData.getValue().getClub2Name()));
        awayTeam.setSortable(false);
        awayTeam.setPrefWidth(400);

        TableColumn<PlayedMatch, String> matchDate = new TableColumn<>("Match Date"); //create matchDate column
        matchDate.setCellValueFactory(matchDateData -> new ReadOnlyObjectWrapper<>(matchDateData.getValue().getDate()));
        matchDate.setSortable(false);
        matchDate.setPrefWidth(400);

        TableColumn<PlayedMatch, Integer> homeTeamGoalsScored = new TableColumn<>("Home Team Goals Scored"); //create homeTeamGoalsScored column
        homeTeamGoalsScored.setCellValueFactory(homeTeamGoalsScoredData -> new ReadOnlyObjectWrapper<>(homeTeamGoalsScoredData.getValue().getClub1GoalsScored()));
        homeTeamGoalsScored.setSortable(false);
        homeTeamGoalsScored.setPrefWidth(300);

        TableColumn<PlayedMatch, Integer> awayTeamGoalsScored = new TableColumn<>("Away Team Goals Scored"); //create awayTeamGoalsScored column
        awayTeamGoalsScored.setCellValueFactory(awayTeamGoalsScoredData -> new ReadOnlyObjectWrapper<>(awayTeamGoalsScoredData.getValue().getClub2GoalsScored()));
        awayTeamGoalsScored.setSortable(false);
        awayTeamGoalsScored.setPrefWidth(300);

        ObservableList<PlayedMatch> tableData = FXCollections.observableArrayList(playedMatchList);  //create an ObservableList to store footballMatch details
        matchTable.getColumns().addAll(homeTeam, awayTeam, matchDate, homeTeamGoalsScored, awayTeamGoalsScored);
        matchTable.setItems(tableData);
        matchTable.setPrefSize(1800,775);

        //add elements to the GridPane
        gridlayout.add(title,1,1,5,1);
        gridlayout.add(matchTable, 1,3,5,25);

        tableData.sort((PlayedMatch object1, PlayedMatch object2) -> { //sort the ObservableList according to ascending order of the each football match's played date
            if (object1 != null && object2 != null) {
                return object1.getDate().compareTo(object2.getDate());
            }
            return 0;
        });

        Scene scene = new Scene(gridlayout,1900,975);
        scene.setFill(Paint.valueOf("#870C21"));
        Stage stage = new Stage();
        stage.setTitle("Football matches sorted by played date");
        stage.sizeToScene();
        stage.setScene(scene);
        stage.showAndWait();

    }


    public void searchMatchesByDate() { //search footballMatch details using the played date
        GridPane gridlayout = new GridPane();
        gridlayout.setStyle("-fx-background-color:#52486B");
        gridlayout.setPadding(new Insets(20, 20, 20, 20));
        gridlayout.setVgap(15);
        gridlayout.setHgap(15);

        TableView<PlayedMatch> matchTable = new TableView<>(); //create the table
        matchTable.setEditable(false);
        matchTable.setStyle("-fx-background-color: #FFFFFF; -fx-cell-size: 40; -fx-font-family: PremierSans-Regular,Arial; -fx-font-size: 20");
        Label placeHolder = new Label("Search by date to get details of the matches played in the Premier League on that day");
        placeHolder.setStyle("-fx-font-family: PremierSans-Bold,Arial; -fx-font-size: 30; -fx-font-weight: BOLD; -fx-text-fill: #1275E6; -fx-text-alignment: center");
        matchTable.setPlaceholder(placeHolder);

        //create labels,buttons and textField
        Label title = new Label("Premier League ");
        title.setStyle("-fx-font-family: PremierSans-Bold,Arial; -fx-font-size: 35; -fx-font-weight: BOLD; -fx-text-fill: #C7CC33");
        GridPane.setHalignment(title, HPos.CENTER);

        TextField searchBox = new TextField();
        searchBox.setPromptText("YYYY-MM-DD");
        searchBox.setPrefSize(220, 40);
        searchBox.setStyle("-fx-font-family: PremierSans-Bold,Arial; -fx-font-size: 18; -fx-font-weight: BOLD; -fx-background-color: #FFFFFF");
        List<String> dates = new ArrayList<>();
        for (PlayedMatch footballMatch : playedMatchList) {
            if (footballMatch.getDate() != null) {
                dates.add(footballMatch.getDate());
            }
        }
        ObservableList<String> suggestionsList = FXCollections.observableArrayList(dates);
        TextFields.bindAutoCompletion(searchBox,suggestionsList); //create a suggestions list for the input for the textField

        Button searchButton = new Button("SEARCH");
        searchButton.setPrefSize(180, 20);
        searchButton.setStyle("-fx-font-family: PremierSans-Bold,Arial; -fx-font-size: 20; -fx-font-weight: BOLD; -fx-background-color: #187580; -fx-text-fill: #FFFFFF");

        TableColumn<PlayedMatch, String> homeTeam = new TableColumn<>("Home Team"); //create homeTeam column
        homeTeam.setCellValueFactory(homeTeamData -> Bindings.createStringBinding(() -> homeTeamData.getValue().getClub1Name()));
        homeTeam.setSortable(false);
        homeTeam.setPrefWidth(400);

        TableColumn<PlayedMatch, String> awayTeam = new TableColumn<>("Away Team"); //create awayTeam column
        awayTeam.setCellValueFactory(awayTeamData -> Bindings.createStringBinding(() -> awayTeamData.getValue().getClub2Name()));
        awayTeam.setSortable(false);
        awayTeam.setPrefWidth(400);

        TableColumn<PlayedMatch, String> matchDate = new TableColumn<>("Match Date"); //create matchDate column
        matchDate.setCellValueFactory(matchDateData -> new ReadOnlyObjectWrapper<>(matchDateData.getValue().getDate()));
        matchDate.setSortable(false);
        matchDate.setPrefWidth(400);

        TableColumn<PlayedMatch, Integer> homeTeamGoalsScored = new TableColumn<>("Home Team Goals Scored"); //create homeTeamGoalsScored column
        homeTeamGoalsScored.setCellValueFactory(homeTeamGoalsScoredData -> new ReadOnlyObjectWrapper<>(homeTeamGoalsScoredData.getValue().getClub1GoalsScored()));
        homeTeamGoalsScored.setSortable(false);
        homeTeamGoalsScored.setPrefWidth(300);

        TableColumn<PlayedMatch, Integer> awayTeamGoalsScored = new TableColumn<>("Away Team Goals Scored"); //create awayTeamGoalsScored column
        awayTeamGoalsScored.setCellValueFactory(awayTeamGoalsScoredData -> new ReadOnlyObjectWrapper<>(awayTeamGoalsScoredData.getValue().getClub2GoalsScored()));
        awayTeamGoalsScored.setSortable(false);
        awayTeamGoalsScored.setPrefWidth(300);

        matchTable.getColumns().addAll(homeTeam, awayTeam, matchDate, homeTeamGoalsScored, awayTeamGoalsScored);
        matchTable.setPrefSize(1800,775);

        gridlayout.add(title,1,1,5,1);
        gridlayout.add(searchBox,2,2);
        gridlayout.add(searchButton,3,2);
        gridlayout.add(matchTable, 1,4,5,25);

        searchBox.setOnMouseClicked(event -> {
            matchTable.getItems().clear();
            searchBox.clear();
        });

        searchButton.setOnAction(event -> {
            String searchDate = searchBox.getText().trim();
            try {
                if (!searchDate.isEmpty()) {
                    String[] splitDate = searchDate.split("-"); //split user input
                    int year = Integer.parseInt(splitDate[0]);
                    int month = Integer.parseInt(splitDate[1]);
                    int date = Integer.parseInt(splitDate[2]);
                    if (year > 0 && month >= 1 && month <= 12 && date >= 1 && date <= Month.of(month).length(Year.isLeap(year))) {
                        String matchDateToSearch = year + "-" + month + "-" + date; // create date string using user input
                        List<PlayedMatch> filteredMatches = playedMatchList.stream().filter(footballMatch -> footballMatch != null) //get a list of matches which have played on the given date
                                .filter(footballMatch -> footballMatch.getDate().equals(matchDateToSearch)).collect(Collectors.toList());
                        if (!filteredMatches.isEmpty()) {
                            ObservableList<PlayedMatch> tableData = FXCollections.observableArrayList(filteredMatches);
                            matchTable.setItems(tableData);
                        } else { //alert if there are no matches played on the given date
                            Alert noMatchingDataAlert = new Alert(Alert.AlertType.INFORMATION);
                            noMatchingDataAlert.setTitle("No Matching Data Alert");
                            noMatchingDataAlert.setContentText("There aren't any matches played on " + matchDateToSearch + " in the Premier League");
                            noMatchingDataAlert.showAndWait();
                            searchBox.clear();
                        }
                    } else { //alert if the given date is invalid
                        Alert invalidSearchAlert = new Alert(Alert.AlertType.WARNING);
                        invalidSearchAlert.setTitle("Invalid Search Alert");
                        invalidSearchAlert.setContentText("Please enter a valid date in the given format (YYYY-MM-DD) into the search bar");
                        invalidSearchAlert.showAndWait();
                        searchBox.clear();
                    }
                } else { //alert if the search item is invalid
                    Alert invalidSearchAlert = new Alert(Alert.AlertType.WARNING);
                    invalidSearchAlert.setTitle("Invalid Search Alert");
                    invalidSearchAlert.setContentText("Please enter a valid date in the given format (YYYY-MM-DD) into the search bar");
                    invalidSearchAlert.showAndWait();
                    searchBox.clear();
                }
            } catch (Exception exception) {
                Alert invalidSearchAlert = new Alert(Alert.AlertType.WARNING);
                invalidSearchAlert.setTitle("Invalid Search Alert");
                invalidSearchAlert.setContentText("Please enter a valid date in the given format (YYYY-MM-DD) into the search bar");
                invalidSearchAlert.showAndWait();
                searchBox.clear();
            }
        });

        Scene scene = new Scene(gridlayout,1900,975);
        scene.setFill(Paint.valueOf("#52486B"));
        Stage stage = new Stage();
        stage.setTitle("Search football matches played in a given date");
        stage.sizeToScene();
        stage.setScene(scene);
        stage.showAndWait();

    }

    public ObservableList<FootballClub> updateClubPositionInGUI(String sortOption) { //update the positions of all football clubs currently playing in the Premier League, to use in GUI
        ObservableList<FootballClub> tableData = FXCollections.observableArrayList(footballClubList);
        switch (sortOption) {
            case "Points" :
                tableData.sort((FootballClub object1, FootballClub object2) -> { //sort the ObservableList according to descending order of the each football club`s points
                    if (object1 != null && object2 != null) {
                        return object2.getPoints() - object1.getPoints();
                    }
                    return 0;
                });
                break;
            case "Goals Scored" :
                tableData.sort((FootballClub object1, FootballClub object2) -> { //sort the ObservableList according to descending order of the each football club`s goals scored
                    if (object1 != null && object2 != null) {
                        return object2.getGoalsScored() - object1.getGoalsScored();
                    }
                    return 0;
                });
                break;
            case "No of wins":
                tableData.sort((FootballClub object1, FootballClub object2) -> { //sort the ObservableList according to descending order of the each football club`s no of wins
                    if (object1 != null && object2 != null) {
                        return object2.getNoOfWins() - object1.getNoOfWins();
                    }
                    return 0;
                });
                break;
        }
        return tableData;
    }
}